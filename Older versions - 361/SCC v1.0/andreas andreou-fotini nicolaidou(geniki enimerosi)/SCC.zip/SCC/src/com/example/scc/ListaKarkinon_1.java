package com.example.scc;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.widget.Button;

public class ListaKarkinon_1 extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_lista_karkinon_1);
		setButton1();
	    setButton2();
	    setButton3();
	    setButton4();
	}

	private void setButton1() {
		// TODO Auto-generated method stub
		Button button1=(Button)findViewById(R.id.button1);
		button1.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				startActivity(new Intent(ListaKarkinon_1.this,General_Inform.class));
			}
		});
		
	}

	private void setButton2() {
		// TODO Auto-generated method stub
		Button button2=(Button)findViewById(R.id.button2);
		button2.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				startActivity(new Intent(ListaKarkinon_1.this,KarkinosMastou.class));
			}
		});
		
	}
	
	private void setButton3() {
		// TODO Auto-generated method stub
		Button button3=(Button)findViewById(R.id.button3);
		button3.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				startActivity(new Intent(ListaKarkinon_1.this,KarkinosTraxilou.class));
			}
		});
		
	}
	
	private void setButton4() {
		// TODO Auto-generated method stub
		Button button4=(Button)findViewById(R.id.button4);
		button4.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				startActivity(new Intent(ListaKarkinon_1.this,KarkinosProstati.class));
			}
		});
		
	}
   

}
