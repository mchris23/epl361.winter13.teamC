package com.example.scc;

import android.os.Bundle;
import android.app.Activity;
import android.app.ListActivity;
import android.view.Menu;
import android.widget.ArrayAdapter;

public class Eksetaseis_dermatos extends ListActivity {

	String [] exams={
			"������� �������� "
			
			
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		//setContentView(R.layout.activity_eksetaseis_mastou);
	setListAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,exams));
	}

	

}
