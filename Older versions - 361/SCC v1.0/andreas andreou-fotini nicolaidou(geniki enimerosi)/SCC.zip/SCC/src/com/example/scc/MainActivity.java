package com.example.scc;

import android.os.Bundle;import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.widget.Button;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    setButton1();
    setButton2();
    setButton3();
    }

	private void setButton1() {
		// TODO Auto-generated method stub
		Button button1=(Button)findViewById(R.id.button1);
		button1.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				startActivity(new Intent(MainActivity.this,ListaKarkinon_1.class));
			}
		});
		
	}

	private void setButton2() {
		// TODO Auto-generated method stub
		Button button2=(Button)findViewById(R.id.button2);
		button2.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				startActivity(new Intent(MainActivity.this,GenikoiTropoiProlipsis.class));
			}
		});
		
	}
	
	private void setButton3() {
		// TODO Auto-generated method stub
		Button button3=(Button)findViewById(R.id.button3);
		button3.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				startActivity(new Intent(MainActivity.this,ListaKarkinon_2.class));
			}
		});
		
	}
   
    
}
