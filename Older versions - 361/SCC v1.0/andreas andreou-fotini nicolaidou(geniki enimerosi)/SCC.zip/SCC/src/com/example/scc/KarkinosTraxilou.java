package com.example.scc;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;

public class KarkinosTraxilou extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_karkinos_traxilou);
	}

	

}
